
//Code to reverse array elememtns
public class Reverse_Array9 {
    public static void main(String[] args) {
        //array initialization
        int[] numbers = {3,4,6,1,9,7,5,8};
        int k;
        int total = numbers.length;
                for(k=total-1; k<numbers.length; k--)
                    System.out.println(numbers[k]+" ");


    }
}
