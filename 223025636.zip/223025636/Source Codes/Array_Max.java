//Finding Largest Number in an array
import java.util.Arrays;

public class Array_Max {
    public static void main(String[] args) {
        //array initialization
        int[] numbers = {34,23,12,45,67,89,234,26,10,30,43};
        int largest =numbers [0];
        int i;
        //for loop to walkthrough the array
        for(i=0; i<numbers.length; i++){
            if(numbers[i]>largest){
                largest = numbers[i];

            }
        }
        System.out.println("The largest array element/number is "+largest);
    }

}
