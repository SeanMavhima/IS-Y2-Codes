//Calculating the average of array elements
public class Average {
    public static void main(String[] args) {
        //array initialization
        int[] numbers = {10,12,34,23,56,78};
        int sum = 0;
        float average = 0;
        for (int i = 0; i < numbers.length; i++) {
            //sum calculation
            sum += numbers[i];
            //average calculation
           average = (float) sum / numbers.length;
        }
        System.out.println("Average of array numbers is: " + average);
    }
}
