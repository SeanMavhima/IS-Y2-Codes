//Code to check if a year is a leap year or not

import java.util.Scanner;
public class Leap_Year {
    public static void main(String[] args) {
      //taking user input:
      Scanner year = new Scanner(System.in);
        System.out.print("Enter a year:");
        int  year1 = year.nextInt();
//leap year is divisible by either 4, 100, or 400,
        if(year1 % 4 ==0 || year1 % 100 ==0 || year1 % 400 ==0) {
            System.out.println(year1 + " Is a Leap Year");
        }else {
            System.out.println(year1 + " Is not a Leap Year");
        }
    }
}
