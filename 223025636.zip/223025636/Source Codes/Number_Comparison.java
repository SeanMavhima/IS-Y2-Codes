//Code to compare 3 numbers entered by user
import java.util.Scanner;
public class Number_Comparison {
    public static void main(String[] args) {
        //userinputs of 3 numbers
        Scanner num1_scanner = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        int number1 = num1_scanner.nextInt();
        Scanner num2_scanner = new Scanner(System.in);
        System.out.print("Enter the second number: ");
        int number2 = num2_scanner.nextInt();
        Scanner num3_scanner = new Scanner(System.in);
        System.out.print("Enter the third number: ");
        int number3 = num3_scanner.nextInt();
//comparisons to determine the largest number
        if (number1 > number2 && number1 > number3) {
            System.out.println(number1 + " is greater than " + number2 + " and " + number3);
        } else if (number2 > number1 && number2 > number3) {
            System.out.println(number2 + " is greater than " + number3 + " and " + number1);
        } else
            if (number3 > number1 && number3 > number2) {
                System.out.println(number3 + " is greater than " + number2 + " and " + number1);
            }
    }
}
