//Triangle number pattern
public class Triangle_Pattern6 {
    public static void main(String[] args) {
        int rows = 7; // Number of rows in the triangle

        for (int i = 1; i <= rows; i++) {
            // Print the rows
            for (int j = 1; j <= rows - i + 1; j++) {
                System.out.print(i);
            }
            //Printing next code line,
            System.out.println();

        }
    }
}
