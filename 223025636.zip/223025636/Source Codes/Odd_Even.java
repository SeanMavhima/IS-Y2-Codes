import javax.swing.*;
import java.util.Scanner;
//Question 1
//ODD OR EVEN CODE

public class Odd_Even {
    public static void main(String[] args) {
        int number;
        //taking user input
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number: ");
        number = input.nextInt();
        //zero checker
        if (number  == 0)
            System.out.println(number + " = Zero");
        //even number checking
        else if(number % 2 == 0) {
            System.out.println(number + " is Even");
        }else { //odd number
            System.out.println(number + " is Odd");

        }
    }
}

