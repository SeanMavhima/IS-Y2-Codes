//Grade based on letters

import java.util.Scanner;

public class Switch_letters {
    public static void main(String[] args) {
        Scanner letter = new Scanner(System.in);
        System.out.print("Enter Grade: ");
        char letter_1 = letter.next().charAt(0);
        switch (letter_1) {
            case 'A':
                System.out.println("The marks range is: 75-100");
                break;
            case 'B':
                System.out.println("The marks range is: 65-74");
                break;
                case 'C':
                    System.out.println("The marks range is: 50-64");
                    break;
            case 'D':
                System.out.println("The marks range is: 40-49");
                break;
            case 'F':
                System.out.println("The marks range is: 0-39");
                break;
            default:
                System.out.println("Invalid input");
        }
    }
}
