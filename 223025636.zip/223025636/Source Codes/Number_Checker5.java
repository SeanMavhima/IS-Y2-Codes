//Number checking, positive , negative or zero
import java.util.Scanner;
public class Number_Checker5 {
    public static void main(String[] args) {
        //taking user input
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = input.nextInt();
        if(number<0)  //negative number checking
            System.out.println(number +" is negative");
        else if (number>0) //positive number chacking
            System.out.println(number +" is positive");
        else //check is the number is zero
            System.out.println("Number is zero");
    }
}
